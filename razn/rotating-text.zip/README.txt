A Pen created at CodePen.io. You can find this one at http://codepen.io/rachsmith/pen/BNKJme.

 I really liked what they did with the text over at http://panda.network/ so I thought I'd have a crack at making my own implementation here.